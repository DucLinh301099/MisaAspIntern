--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "MisaAsp";
--
-- Name: MisaAsp; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "MisaAsp" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "MisaAsp" OWNER TO postgres;

\connect "MisaAsp"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: authenticateuser(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.authenticateuser(p_emailorphonenumber character varying, p_password character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    user_exists BOOLEAN;
BEGIN
    SELECT COUNT(1) > 0
    INTO user_exists
    FROM users
    WHERE (email = p_emailorphonenumber OR phonenumber = p_emailorphonenumber)
    AND "password" = p_password;

    RETURN user_exists;
END;
$$;


ALTER FUNCTION public.authenticateuser(p_emailorphonenumber character varying, p_password character varying) OWNER TO postgres;

--
-- Name: checkemailexists(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.checkemailexists(p_email character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    email_exists BOOLEAN;
BEGIN
    SELECT COUNT(1) > 0
    INTO email_exists
    FROM Users
    WHERE Email = p_Email;

    RETURN email_exists;
END;
$$;


ALTER FUNCTION public.checkemailexists(p_email character varying) OWNER TO postgres;

--
-- Name: createbankaccount(character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.createbankaccount(p_accountnumber character varying, p_bankname character varying, p_branch character varying, p_typeofbank integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_bankaccount_id INT;
BEGIN
    INSERT INTO public.bank_account (accountnumber, bankname, branch, typeofbank)
    VALUES (p_accountnumber, p_bankname, p_branch, p_typeofbank)
    RETURNING id INTO new_bankaccount_id;

    RETURN new_bankaccount_id;
END;
$$;


ALTER FUNCTION public.createbankaccount(p_accountnumber character varying, p_bankname character varying, p_branch character varying, p_typeofbank integer) OWNER TO postgres;

--
-- Name: createcustomer(character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.createcustomer(p_objectid character varying, p_objectname character varying, p_taxcode character varying, p_address character varying, p_phonenumber character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_customer_id integer;
BEGIN
    INSERT INTO Customer(objectId, objectName, taxCode, address, phoneNumber)
    VALUES (p_objectid, p_objectname, p_taxcode, p_address, p_phonenumber)
    RETURNING Id INTO new_customer_id;
    
    RETURN new_customer_id;
END;
$$;


ALTER FUNCTION public.createcustomer(p_objectid character varying, p_objectname character varying, p_taxcode character varying, p_address character varying, p_phonenumber character varying) OWNER TO postgres;

--
-- Name: createemployee(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.createemployee(p_employeecode character varying, p_employeename character varying, p_department character varying, p_mobilephone character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_employee_id INTEGER;
BEGIN
    INSERT INTO Employee (EmployeeCode, EmployeeName, Department, MobilePhone)
    VALUES (p_EmployeeCode, p_EmployeeName, p_Department, p_MobilePhone)
    RETURNING Id INTO new_employee_id;

    RETURN new_employee_id;
END;
$$;


ALTER FUNCTION public.createemployee(p_employeecode character varying, p_employeename character varying, p_department character varying, p_mobilephone character varying) OWNER TO postgres;

--
-- Name: delete_user(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delete_user(user_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Delete from roleaccount table first to maintain referential integrity
    DELETE FROM roleaccount
    WHERE userid = user_id;

    -- Delete from users table
    DELETE FROM users
    WHERE id = user_id;
END;
$$;


ALTER FUNCTION public.delete_user(user_id integer) OWNER TO postgres;

--
-- Name: getallcustomers(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallcustomers() RETURNS TABLE(id integer, objectid character varying, objectname character varying, taxcode character varying, address character varying, phonenumber character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.id, 
        c.objectId, 
        c.objectName, 
        c.taxCode, 
        c.address, 
        c.phoneNumber 
    FROM Customer c;
END;
$$;


ALTER FUNCTION public.getallcustomers() OWNER TO postgres;

--
-- Name: getallemployees(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallemployees() RETURNS TABLE(id integer, employeecode character varying, employeename character varying, department character varying, mobilephone character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        e.id, 
        e.employeecode, 
        e.employeename, 
        e.department, 
        e.mobilePhone 
    FROM Employee e;
END;
$$;


ALTER FUNCTION public.getallemployees() OWNER TO postgres;

--
-- Name: getallservices(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallservices() RETURNS TABLE(id integer, name character varying, location character varying, price character varying, logo text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        services.id,
        services.name,
        services.location,
        services.price,
        services.logo
    FROM
        services;
END;
$$;


ALTER FUNCTION public.getallservices() OWNER TO postgres;

--
-- Name: getallusers(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallusers() RETURNS TABLE(id integer, firstname character varying, lastname character varying, email character varying, phonenumber character varying, roleid integer, rolename character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        u.id AS id, 
        u.firstname, 
        u.lastname, 
        u.email, 
        u.phonenumber, 
        u.roleid, 
        r.rolename
    FROM 
        users u
    JOIN 
        roles r ON u.roleid = r.id;
END;
$$;


ALTER FUNCTION public.getallusers() OWNER TO postgres;

--
-- Name: getbankbytype(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getbankbytype(p_typeofbank integer) RETURNS TABLE(id integer, accountnumber character varying, bankname character varying, branch character varying, typeofbank integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ba.id,
        ba.accountnumber,
        ba.bankname,
        ba.branch,
        ba.typeofbank
    FROM 
        public.bank_account ba
    WHERE 
        ba.typeofbank = p_typeofbank;
END;
$$;


ALTER FUNCTION public.getbankbytype(p_typeofbank integer) OWNER TO postgres;

--
-- Name: getuserbyid(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getuserbyid(p_id integer) RETURNS TABLE(id integer, firstname character varying, lastname character varying, email character varying, phonenumber character varying, roleid integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT u.Id, u.FirstName, u.LastName, u.Email, u.PhoneNumber, u.RoleId
    FROM Users u
    WHERE u.Id = p_id;
END;
$$;


ALTER FUNCTION public.getuserbyid(p_id integer) OWNER TO postgres;

--
-- Name: getusercountbyemail(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getusercountbyemail(p_email character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN (SELECT COUNT(1) FROM Users WHERE Email = p_email);
END;
$$;


ALTER FUNCTION public.getusercountbyemail(p_email character varying) OWNER TO postgres;

--
-- Name: getusercountbyphonenumber(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getusercountbyphonenumber(p_phone_number character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN (SELECT COUNT(1) FROM Users WHERE PhoneNumber = p_phone_number);
END;
$$;


ALTER FUNCTION public.getusercountbyphonenumber(p_phone_number character varying) OWNER TO postgres;

--
-- Name: getuserrole(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getuserrole(p_emailorphonenumber character varying) RETURNS TABLE(userid integer, roleid integer, rolename character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT ra.userid, ra.roleid, r.rolename
    FROM roleaccount ra
    JOIN roles r ON ra.roleid = r.id
    JOIN users u ON ra.userid = u.id
    WHERE u.email = p_emailorphonenumber OR u.phonenumber = p_emailorphonenumber;
END;
$$;


ALTER FUNCTION public.getuserrole(p_emailorphonenumber character varying) OWNER TO postgres;

--
-- Name: registeruser(character varying, character varying, character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.registeruser(p_firstname character varying, p_lastname character varying, p_email character varying, p_phonenumber character varying, p_password character varying, p_roleid integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_user_id INT;
BEGIN
    -- Insert new user into the users table
    INSERT INTO users (firstname, lastname, email, phonenumber, password, roleid)
    VALUES (p_firstname, p_lastname, p_email, p_phonenumber, p_password, p_roleid)
    RETURNING id INTO new_user_id;

    -- Insert into roleaccount table
    INSERT INTO roleaccount (userid, roleid)
    VALUES (new_user_id, p_roleid);

    RETURN new_user_id;
END;
$$;


ALTER FUNCTION public.registeruser(p_firstname character varying, p_lastname character varying, p_email character varying, p_phonenumber character varying, p_password character varying, p_roleid integer) OWNER TO postgres;

--
-- Name: updateuser(integer, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.updateuser(p_user_id integer, p_first_name character varying, p_last_name character varying, p_email character varying, p_phone_number character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE users
    SET
        firstname = p_first_name,
        lastname = p_last_name,
        email = p_email,
        phonenumber = p_phone_number
    WHERE id = p_user_id;
END;
$$;


ALTER FUNCTION public.updateuser(p_user_id integer, p_first_name character varying, p_last_name character varying, p_email character varying, p_phone_number character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: paymentdetail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paymentdetail (
    id integer NOT NULL,
    debit_account character varying(20),
    credit_account character varying(20),
    amount numeric(18,2),
    objectid character varying(50),
    payment_id integer
);


ALTER TABLE public.paymentdetail OWNER TO postgres;

--
-- Name: COLUMN paymentdetail.debit_account; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentdetail.debit_account IS 'tk nợ';


--
-- Name: COLUMN paymentdetail.credit_account; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentdetail.credit_account IS 'tk có';


--
-- Name: COLUMN paymentdetail.amount; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentdetail.amount IS 'số tiền';


--
-- Name: COLUMN paymentdetail.objectid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentdetail.objectid IS 'khóa ngoại - mã khách hàng';


--
-- Name: accounting_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounting_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounting_entries_id_seq OWNER TO postgres;

--
-- Name: accounting_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounting_entries_id_seq OWNED BY public.paymentdetail.id;


--
-- Name: bank_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_account (
    id integer NOT NULL,
    accountnumber character varying(50) NOT NULL,
    bankname character varying(50) NOT NULL,
    branch character varying(50) NOT NULL,
    typeofbank integer NOT NULL
);


ALTER TABLE public.bank_account OWNER TO postgres;

--
-- Name: bank_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bank_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_account_id_seq OWNER TO postgres;

--
-- Name: bank_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bank_account_id_seq OWNED BY public.bank_account.id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id integer NOT NULL,
    objectid character varying(50) NOT NULL,
    objectname character varying(100) NOT NULL,
    taxcode character varying(20) NOT NULL,
    address character varying(200) NOT NULL,
    phonenumber character varying(15) NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_id_seq OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_id_seq OWNED BY public.customer.id;


--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    id integer NOT NULL,
    employeecode character varying(50) NOT NULL,
    employeename character varying(100) NOT NULL,
    department character varying(100) NOT NULL,
    mobilephone character varying(15)
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_id_seq OWNER TO postgres;

--
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_id_seq OWNED BY public.employee.id;


--
-- Name: paymentmaster; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paymentmaster (
    id integer NOT NULL,
    vouchertype character varying(100) NOT NULL,
    paymentmethod character varying(50) NOT NULL,
    description character varying(100) NOT NULL,
    billcontent character varying(100) NOT NULL,
    transaction_date date,
    document_date date,
    document_number character varying(50),
    total_amount numeric(18,2),
    employeecode integer,
    objectname character varying(50),
    address character varying(50),
    bankname character varying(50),
    accountnumber character varying(50),
    finalsettlement date
);


ALTER TABLE public.paymentmaster OWNER TO postgres;

--
-- Name: COLUMN paymentmaster.vouchertype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.vouchertype IS 'loại khoản chi';


--
-- Name: COLUMN paymentmaster.paymentmethod; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.paymentmethod IS 'phương thức thanh toán';


--
-- Name: COLUMN paymentmaster.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.description IS 'diễn giải';


--
-- Name: COLUMN paymentmaster.billcontent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.billcontent IS 'nội dung thanh toán';


--
-- Name: COLUMN paymentmaster.transaction_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.transaction_date IS 'ngày hạch toán';


--
-- Name: COLUMN paymentmaster.document_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.document_date IS 'ngày chứng từ';


--
-- Name: COLUMN paymentmaster.document_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.document_number IS 'số chứng từ';


--
-- Name: COLUMN paymentmaster.total_amount; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.total_amount IS 'tổng tiền';


--
-- Name: COLUMN paymentmaster.employeecode; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.employeecode IS 'khóa ngoại - mã nhân viên';


--
-- Name: COLUMN paymentmaster.objectname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.objectname IS 'khóa ngoại - tên khách hàng';


--
-- Name: COLUMN paymentmaster.address; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.address IS 'khóa ngoại - địa chỉ khách hàng';


--
-- Name: COLUMN paymentmaster.bankname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.bankname IS 'khóa ngoại - tên ngân hàng';


--
-- Name: COLUMN paymentmaster.accountnumber; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.accountnumber IS 'khóa ngoại - số tài khoản';


--
-- Name: COLUMN paymentmaster.finalsettlement; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.finalsettlement IS 'hạn quyết toán';


--
-- Name: payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_id_seq OWNER TO postgres;

--
-- Name: payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_id_seq OWNED BY public.paymentmaster.id;


--
-- Name: roleaccount; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roleaccount (
    id integer NOT NULL,
    userid integer NOT NULL,
    roleid integer NOT NULL
);


ALTER TABLE public.roleaccount OWNER TO postgres;

--
-- Name: roleaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roleaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roleaccount_id_seq OWNER TO postgres;

--
-- Name: roleaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roleaccount_id_seq OWNED BY public.roleaccount.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    rolename character varying(50) NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id integer NOT NULL,
    name character varying(255),
    location character varying(255),
    price character varying(255),
    logo text
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_id_seq OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    firstname character varying(255) NOT NULL,
    lastname character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phonenumber character varying(20) NOT NULL,
    password character varying(255) NOT NULL,
    roleid integer NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: bank_account id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_account ALTER COLUMN id SET DEFAULT nextval('public.bank_account_id_seq'::regclass);


--
-- Name: customer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN id SET DEFAULT nextval('public.customer_id_seq'::regclass);


--
-- Name: employee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee ALTER COLUMN id SET DEFAULT nextval('public.employee_id_seq'::regclass);


--
-- Name: paymentdetail id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentdetail ALTER COLUMN id SET DEFAULT nextval('public.accounting_entries_id_seq'::regclass);


--
-- Name: paymentmaster id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentmaster ALTER COLUMN id SET DEFAULT nextval('public.payment_id_seq'::regclass);


--
-- Name: roleaccount id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roleaccount ALTER COLUMN id SET DEFAULT nextval('public.roleaccount_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: bank_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_account (id, accountnumber, bankname, branch, typeofbank) FROM stdin;
\.
COPY public.bank_account (id, accountnumber, bankname, branch, typeofbank) FROM '$$PATH$$/4879.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, objectid, objectname, taxcode, address, phonenumber) FROM stdin;
\.
COPY public.customer (id, objectid, objectname, taxcode, address, phonenumber) FROM '$$PATH$$/4873.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (id, employeecode, employeename, department, mobilephone) FROM stdin;
\.
COPY public.employee (id, employeecode, employeename, department, mobilephone) FROM '$$PATH$$/4871.dat';

--
-- Data for Name: paymentdetail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paymentdetail (id, debit_account, credit_account, amount, objectid, payment_id) FROM stdin;
\.
COPY public.paymentdetail (id, debit_account, credit_account, amount, objectid, payment_id) FROM '$$PATH$$/4875.dat';

--
-- Data for Name: paymentmaster; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paymentmaster (id, vouchertype, paymentmethod, description, billcontent, transaction_date, document_date, document_number, total_amount, employeecode, objectname, address, bankname, accountnumber, finalsettlement) FROM stdin;
\.
COPY public.paymentmaster (id, vouchertype, paymentmethod, description, billcontent, transaction_date, document_date, document_number, total_amount, employeecode, objectname, address, bankname, accountnumber, finalsettlement) FROM '$$PATH$$/4877.dat';

--
-- Data for Name: roleaccount; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roleaccount (id, userid, roleid) FROM stdin;
\.
COPY public.roleaccount (id, userid, roleid) FROM '$$PATH$$/4883.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, rolename) FROM stdin;
\.
COPY public.roles (id, rolename) FROM '$$PATH$$/4869.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, name, location, price, logo) FROM stdin;
\.
COPY public.services (id, name, location, price, logo) FROM '$$PATH$$/4867.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, firstname, lastname, email, phonenumber, password, roleid) FROM stdin;
\.
COPY public.users (id, firstname, lastname, email, phonenumber, password, roleid) FROM '$$PATH$$/4881.dat';

--
-- Name: accounting_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounting_entries_id_seq', 1, false);


--
-- Name: bank_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_account_id_seq', 16, true);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_id_seq', 19, true);


--
-- Name: employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_id_seq', 20, true);


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_id_seq', 1, false);


--
-- Name: roleaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roleaccount_id_seq', 10, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_id_seq', 8, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 10, true);


--
-- Name: paymentdetail accounting_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentdetail
    ADD CONSTRAINT accounting_entries_pkey PRIMARY KEY (id);


--
-- Name: bank_account bank_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_account
    ADD CONSTRAINT bank_account_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (id);


--
-- Name: paymentmaster payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentmaster
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: paymentmaster employeecode_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentmaster
    ADD CONSTRAINT employeecode_fkey FOREIGN KEY (employeecode) REFERENCES public.employee(id) ON DELETE CASCADE;


--
-- Name: users fk_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_role FOREIGN KEY (roleid) REFERENCES public.roles(id);


--
-- Name: roleaccount fk_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roleaccount
    ADD CONSTRAINT fk_role FOREIGN KEY (roleid) REFERENCES public.roles(id);


--
-- Name: roleaccount fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roleaccount
    ADD CONSTRAINT fk_user FOREIGN KEY (userid) REFERENCES public.users(id);


--
-- Name: paymentdetail payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentdetail
    ADD CONSTRAINT payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.paymentmaster(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

