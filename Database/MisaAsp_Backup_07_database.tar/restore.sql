--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "MisaAsp";
--
-- Name: MisaAsp; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "MisaAsp" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "MisaAsp" OWNER TO postgres;

\connect "MisaAsp"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: authenticateuser(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.authenticateuser(p_emailorphonenumber character varying, p_password character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    user_exists BOOLEAN;
BEGIN
    SELECT COUNT(1) > 0
    INTO user_exists
    FROM users
    WHERE (email = p_emailorphonenumber OR phonenumber = p_emailorphonenumber)
    AND "password" = p_password;

    RETURN user_exists;
END;
$$;


ALTER FUNCTION public.authenticateuser(p_emailorphonenumber character varying, p_password character varying) OWNER TO postgres;

--
-- Name: checkemailexists(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.checkemailexists(p_email character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    email_exists BOOLEAN;
BEGIN
    SELECT COUNT(1) > 0
    INTO email_exists
    FROM Users
    WHERE Email = p_email;

    RETURN email_exists;
END;
$$;


ALTER FUNCTION public.checkemailexists(p_email character varying) OWNER TO postgres;

--
-- Name: createbankaccount(character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.createbankaccount(p_accountnumber character varying, p_bankname character varying, p_branch character varying, p_typeofbank integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_bankaccount_id INT;
BEGIN
    INSERT INTO public.bank_account (accountnumber, bankname, branch, typeofbank)
    VALUES (p_accountnumber, p_bankname, p_branch, p_typeofbank)
    RETURNING id INTO new_bankaccount_id;

    RETURN new_bankaccount_id;
END;
$$;


ALTER FUNCTION public.createbankaccount(p_accountnumber character varying, p_bankname character varying, p_branch character varying, p_typeofbank integer) OWNER TO postgres;

--
-- Name: createcustomer(character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.createcustomer(p_objectid character varying, p_objectname character varying, p_taxcode character varying, p_address character varying, p_phonenumber character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_customer_id integer;
BEGIN
    INSERT INTO Customer(objectId, objectName, taxCode, address, phoneNumber)
    VALUES (p_objectid, p_objectname, p_taxcode, p_address, p_phonenumber)
    RETURNING Id INTO new_customer_id;
    
    RETURN new_customer_id;
END;
$$;


ALTER FUNCTION public.createcustomer(p_objectid character varying, p_objectname character varying, p_taxcode character varying, p_address character varying, p_phonenumber character varying) OWNER TO postgres;

--
-- Name: createemployee(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.createemployee(p_employeecode character varying, p_employeename character varying, p_department character varying, p_phonenumber character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_employee_id INTEGER;
BEGIN
    INSERT INTO Employee (EmployeeCode, EmployeeName, Department, PhoneNumber)
    VALUES (p_EmployeeCode, p_EmployeeName, p_Department, p_PhoneNumber)
    RETURNING Id INTO new_employee_id;

    RETURN new_employee_id;
END;
$$;


ALTER FUNCTION public.createemployee(p_employeecode character varying, p_employeename character varying, p_department character varying, p_phonenumber character varying) OWNER TO postgres;

--
-- Name: delete_user(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delete_user(user_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    deleted_user_id INT;
BEGIN
    -- Delete from roleaccount table first to maintain referential integrity
    DELETE FROM roleaccount
    WHERE userid = user_id;

    -- Delete from users table
    DELETE FROM users
    WHERE id = user_id
    RETURNING id INTO deleted_user_id;

    -- Check if the record was deleted
    IF deleted_user_id IS NOT NULL THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END;
$$;


ALTER FUNCTION public.delete_user(user_id integer) OWNER TO postgres;

--
-- Name: deletepayment(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.deletepayment(paymentmaster_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Delete from paymentdetail table first due to foreign key constraint with cascade
    DELETE FROM public.paymentdetail
    WHERE paymentid = paymentmaster_id;
    
    -- Delete from paymentmaster table
    DELETE FROM public.paymentmaster
    WHERE id = paymentmaster_id;

    -- Check if the record still exists
    IF NOT EXISTS (SELECT 1 FROM public.paymentmaster WHERE id = paymentmaster_id) THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END;
$$;


ALTER FUNCTION public.deletepayment(paymentmaster_id integer) OWNER TO postgres;

--
-- Name: get_payment_with_details_by_id(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_payment_with_details_by_id(paymentmaster_id integer) RETURNS TABLE(id integer, vouchertype character varying, paymentmethod character varying, billcontent character varying, accountingdate character varying, documentdate character varying, documentnumber character varying, totalamount character varying, employeename character varying, objectname character varying, address character varying, bankname character varying, accountnumber character varying, bankaccountid integer, customerid integer, employeeid integer, detailid integer, debitaccount character varying, creditaccount character varying, amount character varying, objectid character varying, detailobjectname character varying, paymentid integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        pm.id, 
        pm.vouchertype, 
        pm.paymentmethod, 
        pm.billcontent, 
        pm.accountingdate, 
        pm.documentdate,
        pm.documentnumber, 
        pm.totalamount, 
        pm.employeename, 
        pm.objectname, 
        pm.address, 
        pm.bankname,
        pm.accountnumber, 
        pm.bankaccountid, 
        pm.customerid, 
        pm.employeeid, 
        pd.id AS detailid, 
        pd.debitaccount, 
        pd.creditaccount, 
        pd.amount, 
        pd.objectid, 
        COALESCE(pd.objectname, '') AS detailobjectname, 
        pd.paymentid
    FROM paymentmaster pm
    LEFT JOIN paymentdetail pd ON pm.id = pd.paymentid
    WHERE pm.id = paymentmaster_id;
END;
$$;


ALTER FUNCTION public.get_payment_with_details_by_id(paymentmaster_id integer) OWNER TO postgres;

--
-- Name: get_payment_with_details_by_id_01(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_payment_with_details_by_id_01(paymentmaster_id integer) RETURNS TABLE(id integer, vouchertype character varying, paymentmethod character varying, billcontent character varying, accountingdate character varying, documentdate character varying, documentnumber character varying, totalamount character varying, employeename character varying, objectname character varying, address character varying, bankname character varying, accountnumber character varying, bankaccountid integer, customerid integer, employeeid integer, detailid integer, debitaccount character varying, creditaccount character varying, amount character varying, objectid character varying, pdobjectname character varying, paymentid integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        pm.id, 
        pm.vouchertype, 
        pm.paymentmethod, 
        pm.billcontent, 
        pm.accountingdate, 
        pm.documentdate,
        pm.documentnumber, 
        pm.totalamount, 
        pm.employeename, 
        pm.objectname, 
        pm.address, 
        pm.bankname,
        pm.accountnumber, 
        pm.bankaccountid, 
        pm.customerid, 
        pm.employeeid, 
        pd.id AS detailid, 
        pd.debitaccount, 
        pd.creditaccount, 
        pd.amount, 
        pd.objectid, 
        pd.objectname as pdobjectname,  
        pd.paymentid
    FROM paymentmaster pm
    LEFT JOIN paymentdetail pd ON pm.id = pd.paymentid
    WHERE pm.id = paymentmaster_id;
END;
$$;


ALTER FUNCTION public.get_payment_with_details_by_id_01(paymentmaster_id integer) OWNER TO postgres;

--
-- Name: getallcustomers(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallcustomers() RETURNS TABLE(id integer, objectid character varying, objectname character varying, taxcode character varying, address character varying, phonenumber character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.id, 
        c.objectId, 
        c.objectName, 
        c.taxCode, 
        c.address, 
        c.phoneNumber 
    FROM Customer c;
END;
$$;


ALTER FUNCTION public.getallcustomers() OWNER TO postgres;

--
-- Name: getallemployees(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallemployees() RETURNS TABLE(id integer, employeecode character varying, employeename character varying, department character varying, phonenumber character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        e.id, 
        e.employeecode, 
        e.employeename, 
        e.department, 
        e.phonenumber 
    FROM Employee e;
END;
$$;


ALTER FUNCTION public.getallemployees() OWNER TO postgres;

--
-- Name: getallpayments(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallpayments() RETURNS TABLE(id integer, vouchertype character varying, paymentmethod character varying, billcontent character varying, accountingdate character varying, documentdate character varying, documentnumber character varying, totalamount character varying, employeename character varying, objectname character varying, address character varying, bankname character varying, accountnumber character varying, bankaccountid integer, customerid integer, employeeid integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        paymentmaster.id,
        paymentmaster.vouchertype,
        paymentmaster.paymentmethod,
        paymentmaster.billcontent,
        paymentmaster.accountingdate,
        paymentmaster.documentdate,
        paymentmaster.documentnumber,
        paymentmaster.totalamount,
        paymentmaster.employeename,
        paymentmaster.objectname,
        paymentmaster.address,
        paymentmaster.bankname,
        paymentmaster.accountnumber,
        paymentmaster.bankaccountid,
        paymentmaster.customerid,
        paymentmaster.employeeid
    FROM public.paymentmaster;
END;
$$;


ALTER FUNCTION public.getallpayments() OWNER TO postgres;

--
-- Name: getallpayments01(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallpayments01() RETURNS TABLE(id integer, vouchertype character varying, paymentmethod character varying, billcontent character varying, accountingdate character varying, documentdate character varying, documentnumber character varying, totalamount character varying, employeename character varying, objectname character varying, address character varying, bankname character varying, accountnumber character varying, bankaccountid integer, customerid integer, employeeid integer, paymentdetails text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT pm.id, pm.vouchertype, pm.paymentmethod, pm.billcontent, pm.accountingdate,
           pm.documentdate, pm.documentnumber, pm.totalamount, pm.employeename,
           pm.objectname, pm.address, pm.bankname, pm.accountnumber,
           pm.bankaccountid, pm.customerid, pm.employeeid,
           COALESCE(
               array_to_json(array_agg(row_to_json(pd.*)))::text,
               '[]'
           ) AS paymentdetails
    FROM public.paymentmaster pm
    LEFT JOIN public.paymentdetail pd ON pm.id = pd.paymentid
    GROUP BY pm.id;
END;
$$;


ALTER FUNCTION public.getallpayments01() OWNER TO postgres;

--
-- Name: getallservices(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallservices() RETURNS TABLE(id integer, name character varying, location character varying, price character varying, logo text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        services.id,
        services.name,
        services.location,
        services.price,
        services.logo
    FROM
        services;
END;
$$;


ALTER FUNCTION public.getallservices() OWNER TO postgres;

--
-- Name: getallusers(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallusers() RETURNS TABLE(id integer, firstname character varying, lastname character varying, email character varying, phonenumber character varying, roleid integer, rolename character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        u.id AS id, 
        u.firstname, 
        u.lastname, 
        u.email, 
        u.phonenumber, 
        u.roleid, 
        r.rolename
    FROM 
        users u
    JOIN 
        roles r ON u.roleid = r.id;
END;
$$;


ALTER FUNCTION public.getallusers() OWNER TO postgres;

--
-- Name: getbankbytype(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getbankbytype(p_typeofbank integer) RETURNS TABLE(id integer, accountnumber character varying, bankname character varying, branch character varying, typeofbank integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ba.id,
        ba.accountnumber,
        ba.bankname,
        ba.branch,
        ba.typeofbank
    FROM 
        public.bank_account ba
    WHERE 
        ba.typeofbank = p_typeofbank;
END;
$$;


ALTER FUNCTION public.getbankbytype(p_typeofbank integer) OWNER TO postgres;

--
-- Name: getuserbyid(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getuserbyid(p_id integer) RETURNS TABLE(id integer, firstname character varying, lastname character varying, email character varying, phonenumber character varying, roleid integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT u.Id, u.FirstName, u.LastName, u.Email, u.PhoneNumber, u.RoleId
    FROM Users u
    WHERE u.Id = p_id;
END;
$$;


ALTER FUNCTION public.getuserbyid(p_id integer) OWNER TO postgres;

--
-- Name: getusercountbyemail(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getusercountbyemail(p_email character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN (SELECT COUNT(1) FROM Users WHERE Email = p_email);
END;
$$;


ALTER FUNCTION public.getusercountbyemail(p_email character varying) OWNER TO postgres;

--
-- Name: getusercountbyphonenumber(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getusercountbyphonenumber(p_phone_number character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN (SELECT COUNT(1) FROM Users WHERE PhoneNumber = p_phone_number);
END;
$$;


ALTER FUNCTION public.getusercountbyphonenumber(p_phone_number character varying) OWNER TO postgres;

--
-- Name: getuserrole(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getuserrole(p_emailorphonenumber character varying) RETURNS TABLE(userid integer, roleid integer, rolename character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT ra.userid, ra.roleid, r.rolename
    FROM roleaccount ra
    JOIN roles r ON ra.roleid = r.id
    JOIN users u ON ra.userid = u.id
    WHERE u.email = p_emailorphonenumber OR u.phonenumber = p_emailorphonenumber;
END;
$$;


ALTER FUNCTION public.getuserrole(p_emailorphonenumber character varying) OWNER TO postgres;

--
-- Name: insert_paymentmaster(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, integer, integer, integer, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_paymentmaster(vouchertype character varying, paymentmethod character varying, billcontent character varying, accountingdate character varying, documentdate character varying, documentnumber character varying, totalamount character varying, employeename character varying, pm_objectname character varying, address character varying, bankname character varying, accountnumber character varying, bankaccountid integer, customerid integer, employeeid integer, paymentdetailsjson text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    paymentid integer;
BEGIN
    -- Insert into paymentmaster
    INSERT INTO public.paymentmaster (
        vouchertype, paymentmethod, billcontent, accountingdate,
        documentdate, documentnumber, totalamount, employeename,
        objectname, address, bankname, accountnumber,
        bankaccountid, customerid, employeeid
    ) VALUES (
        vouchertype, paymentmethod, billcontent, accountingdate,
        documentdate, documentnumber, totalamount, employeename,
        pm_objectname, address, bankname, accountnumber,
        bankaccountid, customerid, employeeid
    )
    RETURNING id INTO paymentid;

    -- Insert into paymentdetail
    INSERT INTO public.paymentdetail (
        debitaccount, creditaccount, amount, objectid, objectname, paymentid
    )
    SELECT 
        detail->>'DebitAccount' AS debitaccount,
        detail->>'CreditAccount' AS creditaccount,
        detail->>'Amount' AS amount,
        detail->>'ObjectId' AS objectid,
        detail->>'ObjectName' AS objectname,
        paymentid
    FROM jsonb_array_elements(paymentDetailsJson::jsonb) AS detail;
   
   RETURN paymentid;

END;
$$;


ALTER FUNCTION public.insert_paymentmaster(vouchertype character varying, paymentmethod character varying, billcontent character varying, accountingdate character varying, documentdate character varying, documentnumber character varying, totalamount character varying, employeename character varying, pm_objectname character varying, address character varying, bankname character varying, accountnumber character varying, bankaccountid integer, customerid integer, employeeid integer, paymentdetailsjson text) OWNER TO postgres;

--
-- Name: registeruser(character varying, character varying, character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.registeruser(p_firstname character varying, p_lastname character varying, p_email character varying, p_phonenumber character varying, p_password character varying, p_roleid integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_user_id INT;
BEGIN
    -- Insert new user into the users table
    INSERT INTO users (firstname, lastname, email, phonenumber, password, roleid)
    VALUES (p_firstname, p_lastname, p_email, p_phonenumber, p_password, p_roleid)
    RETURNING id INTO new_user_id;

    -- Insert into roleaccount table
    INSERT INTO roleaccount (userid, roleid)
    VALUES (new_user_id, p_roleid);

    RETURN new_user_id;
END;
$$;


ALTER FUNCTION public.registeruser(p_firstname character varying, p_lastname character varying, p_email character varying, p_phonenumber character varying, p_password character varying, p_roleid integer) OWNER TO postgres;

--
-- Name: updateuser(integer, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.updateuser(p_user_id integer, p_first_name character varying, p_last_name character varying, p_email character varying, p_phone_number character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE users
    SET
        firstname = p_first_name,
        lastname = p_last_name,
        email = p_email,
        phonenumber = p_phone_number
    WHERE id = p_user_id;
END;
$$;


ALTER FUNCTION public.updateuser(p_user_id integer, p_first_name character varying, p_last_name character varying, p_email character varying, p_phone_number character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bank_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_account (
    id integer NOT NULL,
    accountnumber character varying(50) NOT NULL,
    bankname character varying(50) NOT NULL,
    branch character varying(50) NOT NULL,
    typeofbank integer NOT NULL
);


ALTER TABLE public.bank_account OWNER TO postgres;

--
-- Name: bank_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bank_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_account_id_seq OWNER TO postgres;

--
-- Name: bank_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bank_account_id_seq OWNED BY public.bank_account.id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id integer NOT NULL,
    objectid character varying(50) NOT NULL,
    objectname character varying(100) NOT NULL,
    taxcode character varying(20) NOT NULL,
    address character varying(200) NOT NULL,
    phonenumber character varying(15) NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_id_seq OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_id_seq OWNED BY public.customer.id;


--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    id integer NOT NULL,
    employeecode character varying(50) NOT NULL,
    employeename character varying(100) NOT NULL,
    department character varying(100) NOT NULL,
    phonenumber character varying(15)
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_id_seq OWNER TO postgres;

--
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_id_seq OWNED BY public.employee.id;


--
-- Name: paymentdetail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paymentdetail (
    id integer NOT NULL,
    debitaccount character varying(20) NOT NULL,
    creditaccount character varying(20) NOT NULL,
    amount character varying(20) NOT NULL,
    objectid character varying(50) NOT NULL,
    paymentid integer NOT NULL,
    objectname character varying(100)
);


ALTER TABLE public.paymentdetail OWNER TO postgres;

--
-- Name: COLUMN paymentdetail.debitaccount; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentdetail.debitaccount IS 'tk nợ';


--
-- Name: COLUMN paymentdetail.creditaccount; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentdetail.creditaccount IS 'tk có';


--
-- Name: COLUMN paymentdetail.amount; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentdetail.amount IS 'số tiền';


--
-- Name: COLUMN paymentdetail.objectid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentdetail.objectid IS 'mã đối tượng';


--
-- Name: COLUMN paymentdetail.paymentid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentdetail.paymentid IS 'id của payment_master';


--
-- Name: COLUMN paymentdetail.objectname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentdetail.objectname IS 'tên đối tượng';


--
-- Name: paymentdetail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paymentdetail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.paymentdetail_id_seq OWNER TO postgres;

--
-- Name: paymentdetail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.paymentdetail_id_seq OWNED BY public.paymentdetail.id;


--
-- Name: paymentmaster; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paymentmaster (
    id integer NOT NULL,
    vouchertype character varying(100) NOT NULL,
    paymentmethod character varying(50) NOT NULL,
    billcontent character varying(100),
    accountingdate character varying(50) NOT NULL,
    documentdate character varying(50) NOT NULL,
    documentnumber character varying(50) NOT NULL,
    totalamount character varying(20) NOT NULL,
    employeename character varying(100),
    objectname character varying(50),
    address character varying(50),
    bankname character varying(50) NOT NULL,
    accountnumber character varying(50) NOT NULL,
    bankaccountid integer NOT NULL,
    customerid integer NOT NULL,
    employeeid integer NOT NULL
);


ALTER TABLE public.paymentmaster OWNER TO postgres;

--
-- Name: COLUMN paymentmaster.vouchertype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.vouchertype IS 'Loại thanh toán';


--
-- Name: COLUMN paymentmaster.paymentmethod; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.paymentmethod IS 'phương thức thanh toán';


--
-- Name: COLUMN paymentmaster.billcontent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.billcontent IS 'Nội dung thanh toán';


--
-- Name: COLUMN paymentmaster.accountingdate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.accountingdate IS 'ngày hạch toán';


--
-- Name: COLUMN paymentmaster.documentdate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.documentdate IS 'ngày chứng từ';


--
-- Name: COLUMN paymentmaster.documentnumber; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.documentnumber IS 'số chứng từ';


--
-- Name: COLUMN paymentmaster.totalamount; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.totalamount IS 'số tiền';


--
-- Name: COLUMN paymentmaster.employeename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.employeename IS 'tên nhân viên';


--
-- Name: COLUMN paymentmaster.objectname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.objectname IS 'tên khách hàng';


--
-- Name: COLUMN paymentmaster.address; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.address IS 'địa chỉ của khách hàng';


--
-- Name: COLUMN paymentmaster.bankname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.bankname IS 'tên ngân hàng';


--
-- Name: COLUMN paymentmaster.accountnumber; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.accountnumber IS 'số tài khoản ngân hàng';


--
-- Name: COLUMN paymentmaster.bankaccountid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.bankaccountid IS 'id của tk ngân hàng';


--
-- Name: COLUMN paymentmaster.customerid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.customerid IS 'id của khách hàng';


--
-- Name: COLUMN paymentmaster.employeeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paymentmaster.employeeid IS 'id của nhân viên';


--
-- Name: paymentmaster_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paymentmaster_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.paymentmaster_id_seq OWNER TO postgres;

--
-- Name: paymentmaster_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.paymentmaster_id_seq OWNED BY public.paymentmaster.id;


--
-- Name: roleaccount; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roleaccount (
    id integer NOT NULL,
    userid integer NOT NULL,
    roleid integer NOT NULL
);


ALTER TABLE public.roleaccount OWNER TO postgres;

--
-- Name: roleaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roleaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roleaccount_id_seq OWNER TO postgres;

--
-- Name: roleaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roleaccount_id_seq OWNED BY public.roleaccount.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    rolename character varying(50) NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id integer NOT NULL,
    name character varying(255),
    location character varying(255),
    price character varying(255),
    logo text
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_id_seq OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    firstname character varying(255) NOT NULL,
    lastname character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phonenumber character varying(20) NOT NULL,
    password character varying(255) NOT NULL,
    roleid integer NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: bank_account id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_account ALTER COLUMN id SET DEFAULT nextval('public.bank_account_id_seq'::regclass);


--
-- Name: customer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN id SET DEFAULT nextval('public.customer_id_seq'::regclass);


--
-- Name: employee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee ALTER COLUMN id SET DEFAULT nextval('public.employee_id_seq'::regclass);


--
-- Name: paymentdetail id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentdetail ALTER COLUMN id SET DEFAULT nextval('public.paymentdetail_id_seq'::regclass);


--
-- Name: paymentmaster id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentmaster ALTER COLUMN id SET DEFAULT nextval('public.paymentmaster_id_seq'::regclass);


--
-- Name: roleaccount id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roleaccount ALTER COLUMN id SET DEFAULT nextval('public.roleaccount_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: bank_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_account (id, accountnumber, bankname, branch, typeofbank) FROM stdin;
\.
COPY public.bank_account (id, accountnumber, bankname, branch, typeofbank) FROM '$$PATH$$/4883.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, objectid, objectname, taxcode, address, phonenumber) FROM stdin;
\.
COPY public.customer (id, objectid, objectname, taxcode, address, phonenumber) FROM '$$PATH$$/4881.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (id, employeecode, employeename, department, phonenumber) FROM stdin;
\.
COPY public.employee (id, employeecode, employeename, department, phonenumber) FROM '$$PATH$$/4879.dat';

--
-- Data for Name: paymentdetail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paymentdetail (id, debitaccount, creditaccount, amount, objectid, paymentid, objectname) FROM stdin;
\.
COPY public.paymentdetail (id, debitaccount, creditaccount, amount, objectid, paymentid, objectname) FROM '$$PATH$$/4891.dat';

--
-- Data for Name: paymentmaster; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paymentmaster (id, vouchertype, paymentmethod, billcontent, accountingdate, documentdate, documentnumber, totalamount, employeename, objectname, address, bankname, accountnumber, bankaccountid, customerid, employeeid) FROM stdin;
\.
COPY public.paymentmaster (id, vouchertype, paymentmethod, billcontent, accountingdate, documentdate, documentnumber, totalamount, employeename, objectname, address, bankname, accountnumber, bankaccountid, customerid, employeeid) FROM '$$PATH$$/4889.dat';

--
-- Data for Name: roleaccount; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roleaccount (id, userid, roleid) FROM stdin;
\.
COPY public.roleaccount (id, userid, roleid) FROM '$$PATH$$/4887.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, rolename) FROM stdin;
\.
COPY public.roles (id, rolename) FROM '$$PATH$$/4877.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, name, location, price, logo) FROM stdin;
\.
COPY public.services (id, name, location, price, logo) FROM '$$PATH$$/4875.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, firstname, lastname, email, phonenumber, password, roleid) FROM stdin;
\.
COPY public.users (id, firstname, lastname, email, phonenumber, password, roleid) FROM '$$PATH$$/4885.dat';

--
-- Name: bank_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_account_id_seq', 87, true);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_id_seq', 34, true);


--
-- Name: employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_id_seq', 44, true);


--
-- Name: paymentdetail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paymentdetail_id_seq', 153, true);


--
-- Name: paymentmaster_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paymentmaster_id_seq', 161, true);


--
-- Name: roleaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roleaccount_id_seq', 64, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_id_seq', 8, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 64, true);


--
-- Name: bank_account bank_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_account
    ADD CONSTRAINT bank_account_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (id);


--
-- Name: paymentmaster payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentmaster
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: paymentdetail paymentdetail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentdetail
    ADD CONSTRAINT paymentdetail_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: paymentmaster fk_bank_account; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentmaster
    ADD CONSTRAINT fk_bank_account FOREIGN KEY (bankaccountid) REFERENCES public.bank_account(id);


--
-- Name: paymentmaster fk_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentmaster
    ADD CONSTRAINT fk_customer FOREIGN KEY (customerid) REFERENCES public.customer(id);


--
-- Name: paymentmaster fk_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentmaster
    ADD CONSTRAINT fk_employee FOREIGN KEY (employeeid) REFERENCES public.employee(id);


--
-- Name: users fk_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_role FOREIGN KEY (roleid) REFERENCES public.roles(id);


--
-- Name: roleaccount fk_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roleaccount
    ADD CONSTRAINT fk_role FOREIGN KEY (roleid) REFERENCES public.roles(id);


--
-- Name: roleaccount fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roleaccount
    ADD CONSTRAINT fk_user FOREIGN KEY (userid) REFERENCES public.users(id);


--
-- Name: paymentdetail payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentdetail
    ADD CONSTRAINT payment_id_fkey FOREIGN KEY (paymentid) REFERENCES public.paymentmaster(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

